package com.example

import android.webkit.JavascriptInterface

/**
 * Safe JavaScript interface exposed to the WebView under "AndroidBridge".
 */
class WebAppInterface(
    private val activity: MainActivity,
    private val onScreenChanged: (String) -> Unit
) {
    /**
     * Called by JavaScript when the quiz ends or game over occurs.
     * Returns true if an interstitial ad is being shown, false if bypassed/not ready.
     */
    @JavascriptInterface
    fun requestInterstitial(): Boolean {
        return activity.showInterstitialFromJs()
    }

    /**
     * Called by JavaScript when the player clicks "🎁 Watch Ad".
     */
    @JavascriptInterface
    fun requestRewardedAd() {
        activity.showRewardedFromJs()
    }

    /**
     * Synchronizes active screen ID ('login', 'home', 'rules', 'quiz', 'result')
     * so native Android back navigation operates naturally.
     */
    @JavascriptInterface
    fun setCurrentScreen(screen: String) {
        onScreenChanged(screen)
    }

    /**
     * Returns whether a rewarded ad is currently cached and ready.
     */
    @JavascriptInterface
    fun isRewardedReady(): Boolean {
        return AdManager.isRewardedLoaded()
    }

    /**
     * Triggers tactile haptic vibration feedback.
     */
    @JavascriptInterface
    fun vibrate(milliseconds: Long) {
        activity.vibratePhone(milliseconds)
    }
}
