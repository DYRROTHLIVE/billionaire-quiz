package com.example

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.viewinterop.AndroidView
import org.json.JSONObject

class MainActivity : ComponentActivity() {

    private var webView: WebView? = null
    private var currentScreen: String = "login"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize Google Mobile Ads SDK early
        AdManager.initialize(applicationContext)

        setContent {
            var screenState by remember { mutableStateOf("login") }

            // Handle hardware / gesture back button
            BackHandler(enabled = screenState in listOf("rules", "result", "quiz", "levels", "stats", "modes")) {
                handleBackPressed()
            }

            Scaffold(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF07163B)),
                contentWindowInsets = WindowInsets.safeDrawing
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .windowInsetsPadding(WindowInsets.safeDrawing)
                        .background(Color(0xFF07163B))
                ) {
                    QuizWebView(
                        onScreenUpdated = { screen ->
                            currentScreen = screen
                            runOnUiThread { screenState = screen }
                        },
                        onWebViewCreated = { wv ->
                            webView = wv
                        }
                    )
                }
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Composable
    private fun QuizWebView(
        onScreenUpdated: (String) -> Unit,
        onWebViewCreated: (WebView) -> Unit
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { context ->
                WebView(context).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    setBackgroundColor(android.graphics.Color.parseColor("#07163B"))

                    settings.apply {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        allowFileAccess = true
                        databaseEnabled = true
                        cacheMode = WebSettings.LOAD_DEFAULT
                        mediaPlaybackRequiresUserGesture = false
                        useWideViewPort = true
                        loadWithOverviewMode = true
                    }

                    webChromeClient = object : WebChromeClient() {
                        override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                            val msg = consoleMessage?.message() ?: ""
                            if (msg.contains("X-Afma-Gcache-IsGcacheHit") || msg.contains("unsafe header")) {
                                return true
                            }
                            return super.onConsoleMessage(consoleMessage)
                        }
                    }
                    webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView?, url: String?) {
                            super.onPageFinished(view, url)
                        }
                    }

                    // Attach safe JavaScript bridge
                    addJavascriptInterface(
                        WebAppInterface(this@MainActivity, onScreenUpdated),
                        "AndroidBridge"
                    )

                    loadUrl("file:///android_asset/billionaire_quiz_game.html")
                    onWebViewCreated(this)
                }
            }
        )

        DisposableEffect(Unit) {
            onDispose {
                webView?.destroy()
                webView = null
            }
        }
    }

    /* --------------------------------------------------------------------------
     * JavaScript Bridge Handlers
     * -------------------------------------------------------------------------- */

    /**
     * Triggered by JavaScript finish(win, text).
     * Returns true if interstitial ad presentation started, false if skipped/unavailable.
     */
    fun showInterstitialFromJs(): Boolean {
        if (!AdManager.canShowInterstitial()) {
            return false
        }

        return AdManager.showInterstitial(this) {
            evaluateJs("onInterstitialDismissed()")
        }
    }

    /**
     * Triggered by JavaScript requestRewardedAd().
     */
    fun showRewardedFromJs() {
        AdManager.showRewarded(
            activity = this,
            onRewardGranted = {
                evaluateJs("rewardGranted()")
            },
            onAdClosed = { earned ->
                if (!earned) {
                    evaluateJs("rewardAdClosedWithoutReward()")
                }
            },
            onAdUnavailable = { reason ->
                val quoted = JSONObject.quote(reason)
                evaluateJs("rewardAdUnavailable($quoted)")
            }
        )
    }

    /**
     * Provides tactile haptic feedback for button clicks and game events.
     */
    fun vibratePhone(milliseconds: Long) {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(
                    VibrationEffect.createOneShot(
                        milliseconds.coerceIn(10L, 500L),
                        VibrationEffect.DEFAULT_AMPLITUDE
                    )
                )
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(milliseconds.coerceIn(10L, 500L))
            }
        } catch (_: Exception) {}
    }

    private fun handleBackPressed() {
        evaluateJs("goHome()")
    }

    private fun evaluateJs(script: String) {
        runOnUiThread {
            webView?.evaluateJavascript(script, null)
        }
    }

    override fun onResume() {
        super.onResume()
        webView?.onResume()
    }

    override fun onPause() {
        super.onPause()
        webView?.onPause()
    }
}
