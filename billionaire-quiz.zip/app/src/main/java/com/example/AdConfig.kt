package com.example

/**
 * AdMob Configuration for Billionaire Quiz.
 *
 * Provides official Google test ad unit IDs for safe testing during development
 * and user production ad unit IDs for live releases.
 */
object AdConfig {
    // Official Google Sample Ad Unit IDs for Android
    const val TEST_APP_ID = "ca-app-pub-3940256099942544~3347511713"
    const val TEST_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712"
    const val TEST_REWARDED_ID = "ca-app-pub-3940256099942544/5224354917"

    // User's Production AdMob IDs
    const val PROD_APP_ID = "ca-app-pub-4185730950036994~2477969960"
    const val PROD_INTERSTITIAL_ID = "ca-app-pub-4185730950036994/8721702279"
    const val PROD_REWARDED_ID = "ca-app-pub-4185730950036994/9569991926"

    /**
     * Determines whether to use Google official test ad unit IDs or production ad unit IDs.
     * Set to false to start real live production ads.
     */
    var useTestAds: Boolean = false

    val interstitialAdUnitId: String
        get() = if (useTestAds) TEST_INTERSTITIAL_ID else PROD_INTERSTITIAL_ID

    val rewardedAdUnitId: String
        get() = if (useTestAds) TEST_REWARDED_ID else PROD_REWARDED_ID

    val appId: String
        get() = if (useTestAds) TEST_APP_ID else PROD_APP_ID

    /**
     * Minimum interval in milliseconds between consecutive interstitial ads (throttle).
     * Prevents annoying repeated ads.
     */
    const val MIN_INTERSTITIAL_INTERVAL_MS = 25_000L
}
