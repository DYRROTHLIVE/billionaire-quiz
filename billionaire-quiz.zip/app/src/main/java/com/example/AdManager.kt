package com.example

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.RequestConfiguration
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

/**
 * Singleton AdManager for managing Google Mobile Ads SDK lifecycle,
 * preloading, display, throttling, and callbacks.
 */
object AdManager {
    private const val TAG = "BillionaireQuiz_AdMob"

    private val mainHandler = Handler(Looper.getMainLooper())

    private var isInitialized = false

    // Interstitial Ad state
    private var interstitialAd: InterstitialAd? = null
    private var isLoadingInterstitial = false
    private var lastInterstitialShownTime = 0L

    // Rewarded Ad state
    private var rewardedAd: RewardedAd? = null
    private var isLoadingRewarded = false

    /**
     * Initializes Google Mobile Ads SDK once and preloads initial ads.
     */
    fun initialize(context: Context, onInitialized: () -> Unit = {}) {
        if (isInitialized) {
            onInitialized()
            return
        }

        try {
            val builder = RequestConfiguration.Builder()
            if (AdConfig.useTestAds) {
                builder.setTestDeviceIds(listOf(AdRequest.DEVICE_ID_EMULATOR))
            }
            MobileAds.setRequestConfiguration(builder.build())
        } catch (e: Exception) {
            Log.w(TAG, "Failed to set request configuration: ${e.message}")
        }

        MobileAds.initialize(context) { status ->
            isInitialized = true
            Log.d(TAG, "AdMob SDK Initialized. Using test ads: ${AdConfig.useTestAds}")
            mainHandler.post {
                preloadInterstitial(context.applicationContext)
                preloadRewarded(context.applicationContext)
                onInitialized()
            }
        }
    }

    /* --------------------------------------------------------------------------
     * Interstitial Ads
     * -------------------------------------------------------------------------- */

    fun isInterstitialLoaded(): Boolean = interstitialAd != null

    fun canShowInterstitial(): Boolean {
        if (interstitialAd == null) return false
        val now = SystemClock.elapsedRealtime()
        return (now - lastInterstitialShownTime) >= AdConfig.MIN_INTERSTITIAL_INTERVAL_MS
    }

    private fun createAdRequest(): AdRequest {
        val extras = Bundle().apply {
            putString("npa", "1")
        }
        return AdRequest.Builder()
            .addNetworkExtrasBundle(com.google.ads.mediation.admob.AdMobAdapter::class.java, extras)
            .build()
    }

    fun preloadInterstitial(context: Context) {
        if (interstitialAd != null || isLoadingInterstitial) {
            return
        }

        isLoadingInterstitial = true
        val adUnitId = AdConfig.interstitialAdUnitId
        Log.d(TAG, "Loading Interstitial ad with unit ID: $adUnitId")

        val adRequest = createAdRequest()
        InterstitialAd.load(
            context,
            adUnitId,
            adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    isLoadingInterstitial = false
                    Log.d(TAG, "Interstitial ad loaded successfully.")
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    interstitialAd = null
                    isLoadingInterstitial = false
                    Log.w(TAG, "Interstitial ad failed to load: ${loadAdError.message}")
                }
            }
        )
    }

    /**
     * Shows the interstitial ad if ready and interval has elapsed.
     * Returns true if ad display was started, false otherwise.
     * Guaranteed to invoke [onDismissed] exactly once.
     */
    fun showInterstitial(activity: Activity, onDismissed: () -> Unit): Boolean {
        if (!canShowInterstitial()) {
            Log.d(TAG, "Interstitial ad not ready or throttled. Continuing directly.")
            preloadInterstitial(activity.applicationContext)
            mainHandler.post { onDismissed() }
            return false
        }

        val ad = interstitialAd ?: run {
            preloadInterstitial(activity.applicationContext)
            mainHandler.post { onDismissed() }
            return false
        }

        lastInterstitialShownTime = SystemClock.elapsedRealtime()
        var dismissedCalled = false

        fun safeDismiss() {
            if (!dismissedCalled) {
                dismissedCalled = true
                mainHandler.post { onDismissed() }
            }
        }

        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                Log.d(TAG, "Interstitial ad showed full screen content.")
            }

            override fun onAdDismissedFullScreenContent() {
                Log.d(TAG, "Interstitial ad dismissed by user.")
                interstitialAd = null
                preloadInterstitial(activity.applicationContext)
                safeDismiss()
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                Log.w(TAG, "Interstitial ad failed to show: ${adError.message}")
                interstitialAd = null
                preloadInterstitial(activity.applicationContext)
                safeDismiss()
            }
        }

        mainHandler.post {
            ad.show(activity)
        }
        return true
    }

    /* --------------------------------------------------------------------------
     * Rewarded Ads
     * -------------------------------------------------------------------------- */

    fun isRewardedLoaded(): Boolean = rewardedAd != null

    fun preloadRewarded(context: Context) {
        if (rewardedAd != null || isLoadingRewarded) {
            return
        }

        isLoadingRewarded = true
        val adUnitId = AdConfig.rewardedAdUnitId
        Log.d(TAG, "Loading Rewarded ad with unit ID: $adUnitId")

        val adRequest = createAdRequest()
        RewardedAd.load(
            context,
            adUnitId,
            adRequest,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                    isLoadingRewarded = false
                    Log.d(TAG, "Rewarded ad loaded successfully.")
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    rewardedAd = null
                    isLoadingRewarded = false
                    Log.w(TAG, "Rewarded ad failed to load: ${loadAdError.message}")
                }
            }
        )
    }

    /**
     * Shows rewarded ad to the player.
     * [onRewardGranted] is only called after the player completes watching the ad.
     */
    fun showRewarded(
        activity: Activity,
        onRewardGranted: () -> Unit,
        onAdClosed: (earned: Boolean) -> Unit,
        onAdUnavailable: (reason: String) -> Unit
    ) {
        val ad = rewardedAd
        if (ad == null) {
            Log.d(TAG, "Rewarded ad not loaded yet. Requesting load.")
            preloadRewarded(activity.applicationContext)
            mainHandler.post {
                onAdUnavailable("Ad is loading. Please try again in a few seconds.")
            }
            return
        }

        var rewardEarned = false

        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                Log.d(TAG, "Rewarded ad showed full screen.")
            }

            override fun onAdDismissedFullScreenContent() {
                Log.d(TAG, "Rewarded ad dismissed. Reward earned: $rewardEarned")
                rewardedAd = null
                preloadRewarded(activity.applicationContext)
                mainHandler.post { onAdClosed(rewardEarned) }
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                Log.w(TAG, "Rewarded ad failed to show: ${adError.message}")
                rewardedAd = null
                preloadRewarded(activity.applicationContext)
                mainHandler.post { onAdUnavailable("Ad failed to show. Please try again.") }
            }
        }

        mainHandler.post {
            ad.show(activity) { rewardItem ->
                Log.d(TAG, "User earned reward: ${rewardItem.amount} ${rewardItem.type}")
                rewardEarned = true
                mainHandler.post { onRewardGranted() }
            }
        }
    }
}
